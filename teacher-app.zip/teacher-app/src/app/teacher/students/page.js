import Link from "next/link";
import { requireRole } from "@/lib/auth";
import { listStudents } from "@/lib/data/students";
import { listGroups } from "@/lib/data/groups";
import { GRADE_ORDER, GRADE_LABELS } from "@/lib/labels";
import { createStudentAction } from "@/app/teacher/actions";
import { input, button, card } from "@/app/teacher/ui";

export default async function StudentsPage() {
  await requireRole("TEACHER");
  const [students, groups] = await Promise.all([listStudents(), listGroups()]);

  return (
    <div className="space-y-8">
      <h1 className="text-2xl font-semibold">الطلاب ({students.length})</h1>

      <form action={createStudentAction} className="flex flex-wrap items-end gap-3">
        <label className="flex flex-col gap-1 text-sm">
          اسم الطالب
          <input name="name" required className={input} />
        </label>
        <label className="flex flex-col gap-1 text-sm">
          الصف الدراسي
          <select name="gradeLevel" required className={input}>
            {GRADE_ORDER.map((g) => (
              <option key={g} value={g}>
                {GRADE_LABELS[g]}
              </option>
            ))}
          </select>
        </label>
        <label className="flex flex-col gap-1 text-sm">
          رقم ولي الأمر (اختياري)
          <input name="parentPhone" type="tel" dir="ltr" placeholder="01xxxxxxxxx" className={input} />
        </label>
        <label className="flex flex-col gap-1 text-sm">
          المجموعة (اختياري)
          <select name="groupId" className={input}>
            <option value="">من غير مجموعة</option>
            {groups.map((g) => (
              <option key={g.id} value={g.id}>
                {g.name}
              </option>
            ))}
          </select>
        </label>
        <label className="flex flex-col gap-1 text-sm">
          ملاحظات (اختياري)
          <input name="notes" className={input} />
        </label>
        <button type="submit" className={button}>
          إضافة طالب
        </button>
      </form>

      {students.length === 0 ? (
        <p className="text-gray-500">مفيش طلاب لسه.</p>
      ) : (
        <ul className={card}>
          {students.map((s) => (
            <li key={s.id}>
              <Link
                href={`/teacher/students/${s.id}`}
                className="flex flex-wrap items-center justify-between gap-2 px-4 py-3 hover:bg-gray-500/10"
              >
                <span className="font-medium">
                  {s.name}{" "}
                  <span className="text-sm font-normal text-gray-500">
                    ({GRADE_LABELS[s.gradeLevel]})
                  </span>
                </span>
                <span className="text-sm text-gray-500">
                  {s.enrollments.length > 0
                    ? s.enrollments.map((e) => e.group.name).join("، ")
                    : "من غير مجموعة"}
                  {s.parents.length > 0 && " - ولي الأمر مربوط"}
                </span>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
